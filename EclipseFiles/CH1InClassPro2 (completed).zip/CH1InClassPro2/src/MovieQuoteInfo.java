
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("I wanted to see what you'd do. And you didn't disappoint! You let five people die. Even to a guy like me, that's cold");
		System.out.println("The Dark Knight");
		System.out.println("2008");

	}

}
