// Sean Sasser 8/26/24 CH1
public class SongLyrics {

	public static void main(String[] args) {

		System.out.println("Head, Shoulders Knees and Toes Knees and Toes");
		System.out.println("Eyes and Ears and Mouth and Nose");
	}

}
